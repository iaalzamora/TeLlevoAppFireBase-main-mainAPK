import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-car',
  templateUrl: './login-car.component.html',
  styleUrls: ['./login-car.component.scss'],
})
export class LoginCarComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
