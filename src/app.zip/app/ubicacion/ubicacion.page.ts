import { Component, OnInit } from '@angular/core';
import { ToastController } from '@ionic/angular';
import { UbicacionService } from '../services/ubicacion.service';

@Component({
  selector: 'app-ubicacion',
  templateUrl: './ubicacion.page.html',
  styleUrls: ['./ubicacion.page.scss'],
})
export class UbicacionPage implements OnInit {
  ubicacionInfo: any;

  constructor(private toastController: ToastController, private ubicacionService: UbicacionService) { }

  async mostrarMensajeRedNoDisponible() {
    const toast = await this.toastController.create({
      message: 'Aún no tenemos esta red :D',
      duration: 2000,
      position: 'bottom'
    });
    await toast.present();
  }

  
  ngOnInit() {
    const ubicacionData = {
      text: 'white house',
      place: 'washington DC',
      // otros datos que necesites
    };

    this.ubicacionService.getUbicacion(ubicacionData).subscribe(
      response => {
        console.log(response);
        this.ubicacionInfo = {
          place: response.place || 'No disponible',
          latitude: response.latitude,
          longitude: response.longitude,
          mapUrl: response.mapUrl // Si la API devuelve una URL de imagen del mapa
        };
      },
      error => {
        console.error('Error al obtener la ubicación:', error);
      }
    );
  }
}