import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UbicacionService {

  private apiUrl = 'https://google-api31.p.rapidapi.com/map';
  private headers = new HttpHeaders({
    'x-rapidapi-key': '438284335fmsha89fe88b67e67c3p1b738fjsn5bf0b3d02de6',
    'x-rapidapi-host': 'google-api31.p.rapidapi.com',
    'Content-Type': 'application/json'
  });

  constructor(private http: HttpClient) {}

  getUbicacion(data: any): Observable<any> {
    return this.http.post(this.apiUrl, data, { headers: this.headers });
  }
}
